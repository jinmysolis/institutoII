<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        
    
<?php echo $__env->make('includes.menuIconos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
  
        
 <div class="home-container">
       
        
  
   <?php echo $__env->make('includes.menuLateral', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
        
        
   <div class="central">
      
      <div class="formulario_create_empleo">
          <br><br>
 
     <?php echo Form::open(['url'=>'/empresas','method'=>'POST','files'=>'true']); ?>

<!--      <form  role="form" method="POST" files="true"  action="<?php echo e(url('/empresas')); ?>">-->
           <?php echo e(csrf_field()); ?>

     <div class="form-group <?php echo e($errors->has('logo_compañia') ? ' has-error' : ''); ?>">
                           
                            <div class="col-md-9">
                                <label for="cover" class="text-center">Logo compañia</label>  
                                <input id="cover" type="file" class="form-control" name="cover" value="<?php echo e(old('cover')); ?>" required autofocus>
<!--                                 <?php echo e(Form::file('cover')); ?>-->
                                <?php if($errors->has('cover')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('cover')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
     
     <div class="form-group<?php echo e($errors->has('informacion_empresa') ? ' has-error' : ''); ?>">
                           
                            <div class="col-md-9">
                                <label for="informacion_empresa" class="text-center">Informacion de empresa</label>  
                                <input id="informacion_empresa" type="text" class="form-control" name="informacion_empresa" value="<?php echo e(old('informacion_empresa')); ?>" required autofocus>

                                <?php if($errors->has('informacion_empresa')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('informacion_empresa')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
     
     
     <div class="form-group<?php echo e($errors->has('numero_tributario') ? ' has-error' : ''); ?>">
                            
                            <div class="col-md-9">
                                <label for="numero_tributario" class="text-center">Numero tributario</label> 
                                <input id="numero_tributario" type="number" class="form-control" name="numero_tributario" value="<?php echo e(old('numero_tributario')); ?>" required autofocus>

                                <?php if($errors->has('numero_tributario')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('numero_tributario')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div><!--
     
-->     <div class="form-group<?php echo e($errors->has('sitio_web') ? ' has-error' : ''); ?>">
                          
                            <div class="col-md-9">
                                 <label for="sitio_web" class="text-center">Sitio web</label>  
                                 <input id="sitio_web" type="url" class="form-control" name="sitio_web" value="<?php echo e(old('sitio_web')); ?>" required autofocus>

                                <?php if($errors->has('sitio_web')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('sitio_web')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
     
     <div class="form-group<?php echo e($errors->has('lema') ? ' has-error' : ''); ?>">
                          
                            <div class="col-md-9">
                                <label for="lema" class="text-center">Lema</label>  
                                <input id="lema" type="text" class="form-control" name="lema" value="<?php echo e(old('lema')); ?>" required autofocus>

                                <?php if($errors->has('lema')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('lema')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div><!--
     
-->     <div class="form-group<?php echo e($errors->has('objeto_social') ? ' has-error' : ''); ?>">
                           
                            <div class="col-md-9">
                                 <label for="objeto_social" class="text-center">Descripcion del objetivo social</label> 
                                
                             <textarea rows="4" cols="50" id="objeto_social" type="text" class="form-control" name="objeto_social" value="<?php echo e(old('objeto_social')); ?>" required autofocus>
                                
                                </textarea>
                                <?php if($errors->has('objeto_social')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('objeto_social')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
     
     <div class="form-group<?php echo e($errors->has('Direccion_postal') ? ' has-error' : ''); ?>">
                          
                            <div class="col-md-9">
                                 <label for="Direccion_postal" class="text-center">Direccion postal</label>  
                                <input id="Direccion_postal" type="text" class="form-control" name="Direccion_postal" value="<?php echo e(old('Direccion_postal')); ?>" required autofocus>
                                   
                                <?php if($errors->has('Direccion_postal')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('Direccion_postal')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
     


    <div class="form-group<?php echo e($errors->has('ciudad') ? ' has-error' : ''); ?>">
                           
                            <div class="col-md-9">
                                <label for="ciudad2" class="text-center">Ciudad</label>  
                                <input id="ciudad2" type="text" class="form-control" name="ciudad2" value="<?php echo e(old('ciudad2')); ?>" required autofocus>

                                <?php if($errors->has('ciudad2')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('ciudad2')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
     
     <div class="form-group<?php echo e($errors->has('estado2') ? ' has-error' : ''); ?>">
                          
                            <div class="col-md-9">
                                 <label for="estado2" class="text-center">Estado</label>  
                                <input id="estado2" type="text" class="form-control" name="estado2" value="<?php echo e(old('estado2')); ?>" required autofocus>

                                <?php if($errors->has('estado2')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('estado2')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
     
        <div class="form-group<?php echo e($errors->has('codigo_postal') ? ' has-error' : ''); ?>">
                         
                            <div class="col-md-9">
                                  <label for="codigo_postal" class="text-center">Codigo postal</label>  
                                <input id="codigo_postal" type="number" class="form-control" name="codigo_postal" value="<?php echo e(old('codigo_postal')); ?>" required autofocus>

                                <?php if($errors->has('codigo_postal')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('codigo_postal')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
     
     <div class="form-group<?php echo e($errors->has('pais2') ? ' has-error' : ''); ?>">
                           
                            <div class="col-md-9">
                                 <label for="pais2" class="text-center">Pais</label> 
                                <input id="pais2" type="text" class="form-control" name="pais2" value="<?php echo e(old('pais2')); ?>" required autofocus>

                                <?php if($errors->has('pais2')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('pais2')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div><!--
     
     
-->     <div class="form-group<?php echo e($errors->has('telefono') ? ' has-error' : ''); ?>">
                             
                            <div class="col-md-9">
                                <label for="telefono" class="text-center">Telefono</label>
                                <input id="telefono" type="number" class="form-control" name="telefono" value="<?php echo e(old('telefono')); ?>" required autofocus>

                                <?php if($errors->has('telefono')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('telefono')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>

<div class="form-group<?php echo e($errors->has('nombre_contacto') ? ' has-error' : ''); ?>">
                           
                            <div class="col-md-9">
                                 <label for="nombre_contacto" class="text-center">Nombre de contacto</label> 
                                <input id="nombre_contacto" type="text" class="form-control" name="nombre_contacto" value="<?php echo e(old('nombre_contacto')); ?>" required autofocus>

                                <?php if($errors->has('nombre_contacto')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('nombre_contacto')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>

<div class="form-group<?php echo e($errors->has('cargo') ? ' has-error' : ''); ?>">
                          
                            <div class="col-md-9">
                                 <label for="cargo" class="text-center">Cual es el cargo?</label>  
                                <input id="cargo" type="text" class="form-control" name="cargo" value="<?php echo e(old('cargo')); ?>" required autofocus>

                                <?php if($errors->has('cargo')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('cargo')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>


    

    <div class="form-group<?php echo e($errors->has('autorizacion') ? ' has-error' : ''); ?>">
                           
                            <div class="col-md-9">
                                <label for="autorizacion" class="text-center">Esta autorizado para actuar en nombre de la empresa</label> 
                                <div class="text-center">
                                <label class="radio-inline"><input type="radio" name="autorizacion" value="si" id="autorizacion">Si</label>
                               
                                <label class="radio-inline"><input type="radio" name="autorizacion" value="no" id="autorizacion">No</label>
                                </div>
                                <?php if($errors->has('autorizacion')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('autorizacion')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>

<div class="form-group<?php echo e($errors->has('socio') ? ' has-error' : ''); ?>">
                          
                            <div class="col-md-9">
                                 <label for="socio" class="text-center">Es socio?</label> 
                                 <div class="text-center">
                                <label class="radio-inline"><input type="radio" name="socio" value="si" id="socio">Si</label>
                               
                                <label class="radio-inline"><input type="radio" name="socio" value="no" id="socio">No</label>
                                </div>
                                <?php if($errors->has('socio')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('socio')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>

<div class="form-group<?php echo e($errors->has('representante_legal') ? ' has-error' : ''); ?>">
                           
                            <div class="col-md-9">
                                <label for="representante_legal" class="text-center">Es representante legal?</label> 
                                <div class="text-center">
                                <label class="radio-inline"><input type="radio" name="representante_legal" value="si" id="representante_legal">Si</label>
                               
                                <label class="radio-inline"><input type="radio" name="representante_legal" value="no" id="representante_legal">No</label>
                            </div>
                                <?php if($errors->has('socio')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('representante_legal')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
       
     
  
     <p>
 <center><button type="submit" class="btn btn-primary btn-lg">Registrar</button></center>
 </p>
     <?php echo Form::close(); ?> 
      </div>
      
   </div>   
      
      
       <?php echo $__env->make('includes.Banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      
      
      
      
      
      
    
  </nav>
     
       
        
        
        
        
        
        </div>
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.myapp4', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>