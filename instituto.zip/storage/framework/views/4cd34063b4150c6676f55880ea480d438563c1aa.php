<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
    <div class="row">
        
    
<?php echo $__env->make('includes.menuIconos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
  
        
 <div class="home-container">
       
        
  
   <?php echo $__env->make('includes.menuLateral', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
        
        
      <div class="central">
          
          <div class="dos-columna-menu-panel">
          
          <ul class="ul-menu-panel1">
               <li><a class="btn btn-lg btn-success text-left" href="#">
                       <img src="img/menbresia/menbresia1.png" alt="" ></a> <div  class="text-center text-ul-color">Alumno</div>
               </li>
                <li><a class="btn btn-lg btn-success text-left" href="#">
                     <img src="img/menbresia/menbresia2.png" alt="" ></a> <div  class="text-center text-ul-color">Profesor</div>
                </li>
                 <li><a class="btn btn-lg btn-success text-left" href="#">
                     <img src="img/menbresia/menbresia3.png" alt="" ></a> <div  class="text-center text-ul-color">Mentor</div>
                 </li>
                  <li><a class="btn btn-lg btn-success text-left" href="#">
                     <img src="img/menbresia/menbresia4.png" alt="" ></a> <div  class="text-center text-ul-color">Promotor</div>
                  </li>
                  <li><a class="btn btn-lg btn-success text-left" href="#">
                     <img src="img/menbresia/menbresia5.png" alt="" ></a> <div  class="text-center text-ul-color">Pionero</div>
                  </li>
              
              
          </ul>
          
          <ul class="ul-menu-panel">
               <li><a class="btn btn-lg btn-success text-left" href="#">
                     <img src="img/menbresia/menbresia10.png" alt="" ></a><div  class="text-center text-ul-color">Freelance</div>
               </li>
                <li><a class="btn btn-lg btn-success text-left" href="#">
                     <img src="img/menbresia/menbresia9.png" alt="" ></a> <div  class="text-center text-ul-color">Tutor</divt>
                </li>
                 <li><a class="btn btn-lg btn-success text-left" href="#">
                     <img src="img/menbresia/menbresia8.png" alt="" ></a> <div  class="text-center text-ul-color">Inversor</div>
                 </li>
                  <li><a class="btn btn-lg btn-success text-left" href="#">
                     <img src="img/menbresia/menbresia7.png" alt="" ></a><div  class="text-center text-ul-color">Socio</div>
                  </li>
                  <li><a class="btn btn-lg btn-success text-left" href="#">
                          <img src="img/menbresia/menbresia6.png" alt="" ></a><div  class="text-center text-ul-color">Afiliados</div>
                  </li>
              
              
          </ul>
              
         </div>
   
     </div>
      
      
      
      
      
      
      
   
  
     <?php echo $__env->make('includes.banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>     
       
        
        
    </div>    
        
        
        </div>
    
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.myapp4', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>