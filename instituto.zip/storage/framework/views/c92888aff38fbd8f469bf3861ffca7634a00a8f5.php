<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.menuIconos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 


<div class="home-container">
      <?php if(auth()->user()->tipoCuenta === 'personal'): ?> 
           <?php echo $__env->make('includes.menuLateralPersona', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
      <?php else: ?>
        
      <?php echo $__env->make('includes.menuLateral', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
        
        
    <?php endif; ?>
       
       <div class="central">
            <?php echo $__env->make('includes.menuEmpleosCurriculum', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

           <div class="alert alert-success" role="alert">
            <h1>Otros conocimientos</h1>
<div class="list-group" id="list-group-showOfertas">
    
    <?php $__currentLoopData = $user->conocimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conocimientos): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <a class="list-group-item color-text" href="#">&nbsp;TITUTLO:  <div class="text-center color-text"><?php echo e($conocimientos->titulo); ?></div> </a>
    <a class="list-group-item color-text" href="#">&nbsp;DESCRIPCION:  <div class="text-center color-text"><?php echo e($conocimientos->descripcion); ?></div> </a>
   
    
     <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    
  

</div>
                         

             
         </div>
        
                          <form>
                            
                              <input type="button" value="volver atrás" name="volver atrás2" onclick="history.back()" class="btn btn-success btn-lg"/>
                            
                          </form>
       
          
        </div> 
       
       <?php echo $__env->make('includes.banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>     
    
</div>





 <?php echo e($user->name); ?>

<h1>pagia donde van las experiencias</h1>
<?php $__currentLoopData = $user->experiencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experiencia): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
 <a class="list-group-item color-text" href="#"><i class="fa fa-university fa-fw fa-3x" aria-hidden="true"></i>&nbsp;INFORMACION:  <div class="text-center color-text"><?php echo e($experiencia->nombre_empresa); ?></div> </a>

<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.myapp4', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>