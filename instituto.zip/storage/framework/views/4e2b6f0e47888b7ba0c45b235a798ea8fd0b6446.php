<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
    <div class="row">
        
    
<?php echo $__env->make('includes.menuIconos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
  
        
 <div class="home-container">
       
        
  
  <?php if(auth()->user()->tipoCuenta === 'personal'): ?> 
           <?php echo $__env->make('includes.menuLateralPersona', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
      <?php else: ?>
        
      <?php echo $__env->make('includes.menuLateral', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
        
        
    <?php endif; ?>
        
        
      <div class="central">
          
          <div class="dos-columna-menu-panel">
          
          <ul class="ul-menu-panel1">
               <li><a class="btn btn-lg btn-success text-left" href="#">
                       <img src="img/panel1.png" alt="" ></a> <div  class="text-center">Ventas</div>
               </li>
                <li><a class="btn btn-lg btn-success text-left" href="#">
                     <img src="img/panel2.png" alt="" ></a> <div  class="text-center">Afiliaciones</div>
                </li>
                 <li><a class="btn btn-lg btn-success text-left" href="#">
                     <img src="img/panel3.png" alt="" ></a> <div  class="text-center">Mis compras</div>
                 </li>
                  <li><a class="btn btn-lg btn-success text-left" href="#">
                     <img src="img/panel4.png" alt="" ></a> <div  class="text-center">Mensaje</div>
                  </li>
                  <li><a class="btn btn-lg btn-success text-left" href="#">
                     <img src="img/panel5.png" alt="" ></a> <div  class="text-center">Saldo</div>
                  </li>
              
              
          </ul>
          
          <ul class="ul-menu-panel">
               <li><a class="btn btn-lg btn-success text-left" href="#">
                     <img src="img/panel6.png" alt="" ></a><div  class="text-center">Mis Productos</div>
               </li>
                <li><a class="btn btn-lg btn-success text-left" href="#">
                     <img src="img/panel7.png" alt="" ></a> <div  class="text-center">Coproducciones</divt>
                </li>
                 <li><a class="btn btn-lg btn-success text-left" href="#">
                     <img src="img/panel8.png" alt="" ></a> <div  class="text-center">Analytics</div>
                 </li>
                  <li><a class="btn btn-lg btn-success text-left" href="#">
                     <img src="img/panel9.png" alt="" ></a><div  class="text-center">Recibos</div>
                  </li>
                  <li><a class="btn btn-lg btn-success text-left" href="#">
                          <img src="img/panel10.png" alt="" ></a><div  class="text-center">Reembolsos</div>
                  </li>
              
              
          </ul>
              
         </div>
   
     </div>
      
      
      
      
      
      
      
   
  
     <?php echo $__env->make('includes.banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>     
       
        
        
    </div>    
        
        
        </div>
    
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.myapp4', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>