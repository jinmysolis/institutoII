<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.menuIconos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

<div class="home-container">
      <?php if(auth()->user()->tipoCuenta === 'personal'): ?> 
           <?php echo $__env->make('includes.menuLateralPersona', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
      <?php else: ?>
        
      <?php echo $__env->make('includes.menuLateral', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
        
        
    <?php endif; ?>
       
       <div class="central">
            <?php echo $__env->make('includes.menuEmpleosCurriculum', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

           <div class="alert alert-success" role="alert">
            <h1>Estudios realizados</h1>
<div class="list-group" id="list-group-showOfertas">
    <div class="alert alert-success" role="alert">
      FORMACION PRIMARIA
    </div>
    <a class="list-group-item color-text" href="#">&nbsp;CENTRO EDUCATIVO:  <div class="text-center color-text"><?php echo e($formacion->centro_educativo_primaria); ?></div> </a>
    <a class="list-group-item color-text" href="#">&nbsp;ESTADO: <div class="text-center color-text"><?php echo e($formacion->estado_primaria); ?></div></a>
     <a class="list-group-item color-text" href="#">&nbsp;DESDE:<div class="text-center color-text"><?php echo e($formacion->ano_inicio_primaria); ?></div></a>
    <a class="list-group-item color-text" href="#">&nbsp; HASTA :<div class="text-center color-text"><?php echo e($formacion->ano_fin_primaria); ?></div></a>
     <div class="alert alert-success" role="alert">
       FORMACION SECUNDARIA
     </div>
    <a class="list-group-item color-text" href="#">&nbsp;CENTRO EDUCATIVO: <div class="text-center color-text"><?php echo e($formacion->centro_educativo_secundaria); ?> </div></a>
    <a class="list-group-item color-text" href="#">&nbsp;ESTADO:  <div class="text-center color-text"><?php echo e($formacion->estado_secundaria); ?></div> </a>
    <a class="list-group-item color-text" href="#">&nbsp;DESDE: <div class="text-center color-text"><?php echo e($formacion->ano_inicio_secundaria); ?></div></a>
    <a class="list-group-item color-text" href="#">&nbsp;HASTA : <div class="text-center color-text"><?php echo e($formacion->ano_fin_secundaria); ?></div></a>
    <div class="alert alert-success" role="alert">
       UNIVERSIDAD
    </div>
    <a class="list-group-item color-text" href="#">&nbsp; CENTRO EDUCATIVO <div class="text-center color-text"><?php echo e($formacion->centro_educativo_universidad); ?></div></a>
    <a class="list-group-item color-text" href="#">&nbsp; ESTADO: <div class="text-center color-text"><?php echo e($formacion->estado_universidad); ?> </div></a>
    <a class="list-group-item color-text" href="#">&nbsp; DESDE: <div class="text-center color-text"><?php echo e($formacion->ano_inicio_universidad); ?> </div></a>
    <a class="list-group-item color-text" href="#">&nbsp; HASTA : <div class="text-center color-text"><?php echo e($formacion->ano_fin_universidad); ?> </div></a>
    <div class="alert alert-success" role="alert">
       POSGRADO
    </div>
    <a class="list-group-item color-text" href="#">&nbsp; CENTRO EDUCATIVO <div class="text-center color-text"><?php echo e($formacion->centro_educativo_posgrado); ?> </div></a>
    <a class="list-group-item color-text" href="#">&nbsp;ESTADO: <div class="text-center color-text"><?php echo e($formacion->estado_posgrado); ?> </div></a>
    <a class="list-group-item color-text" href="#">&nbsp;DESDE:<div class="text-center color-text"><?php echo e($formacion->ano_inicio_posgrado); ?> </div></a>
    <a class="list-group-item color-text" href="#">&nbsp; HASTA : <div class="text-center color-text"><?php echo e($formacion->ano_fin_posgrado); ?> </div></a>
    
  

</div>
    <?php echo $__env->make('includes.menuCurriculum', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 


             
         </div>
        
       
       
          
        </div> 
       
       <?php echo $__env->make('includes.banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>     
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.myapp4', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>