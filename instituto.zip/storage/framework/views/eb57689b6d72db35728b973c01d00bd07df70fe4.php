<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        
    
<?php echo $__env->make('includes.menuEmpresaEmpleos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
  
        
 <div class="home-container">
       
               
        
   <div class="central">
      
      <div class="formulario_create_empleo">
          <br><br>
 
     <?php echo Form::open(['url'=>'/publicarOferta','method'=>'POST','files'=>'true']); ?>

<!--      <form  role="form" method="POST" files="true"  action="<?php echo e(url('/empresas')); ?>">-->
           <?php echo e(csrf_field()); ?>

           
    <div class="alert alert-success" role="alert">
        Datos de la Oferta
    </div>
           
     
     <div class="form-group<?php echo e($errors->has('titulo_oferta') ? ' has-error' : ''); ?>">
                           
                            <div class="col-md-9">
                                <label for="titulo_oferta" class="text-center">Titulo oferta</label>  
                                <input id="titulo_oferta" type="text" class="form-control" name="titulo_oferta" value="<?php echo e(old('titulo_oferta')); ?>" required autofocus>

                                <?php if($errors->has('titulo_oferta')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('titulo_oferta')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
           
           
    <div class="form-group<?php echo e($errors->has('area') ? ' has-error' : ''); ?>">
                           
                            <div class="col-md-9">
                                 <label for="area" class="text-center">Area</label> 

                                 <select class="form-control" name="area" value="<?php echo e(old('area')); ?>" required autofocus>
                                    <option selected="selected" value="0">Selecciona el sector</option>
                                    <option value="2">Agricultura / Pesca / Ganadería</option>
                                    <option value="5">Construcción / obras</option>
                                    <option value="7">Educación</option>
                                    <option value="8">Energía</option>
                                    <option value="9">Entretenimiento / Deportes</option>
                                    <option value="15">Fabricación</option>
                                    <option value="10">Finanzas / Banca</option>
                                    <option value="16">Gobierno / No Lucro</option>
                                    <option value="12">Hostelería / Turismo</option>
                                    <option value="3">Informática / Hardware</option>
                                    <option value="4">Informática / Software</option>
                                    <option value="13">Internet</option>
                                    <option value="23">Legal / Asesoría</option>
                                    <option value="18">Materias Primas</option>
                                    <option value="14">Medios de Comunicación</option>
                                    <option value="1">Publicidad / RRPP</option>
                                    <option value="19">RRHH / Personal</option>
                                    <option value="11">Salud / Medicina</option>
                                    <option value="17">Servicios Profesionales</option>
                                    <option value="21">Telecomunicaciones</option>
                                    <option value="22">Transporte</option>
                                    <option value="6">Venta al consumidor</option>
                                    <option value="20">Venta al por mayor</option>


                                  </select>

                                <?php if($errors->has('area')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('area')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
           
           
    <div class="form-group<?php echo e($errors->has('tipo_jornada') ? ' has-error' : ''); ?>">
                           
                            <div class="col-md-9">
                                 <label for="tipo_jornada" class="text-center">Tipo de jornada</label> 

                                 <select class="form-control" name="tipo_jornada" value="<?php echo e(old('tipo_jornada')); ?>" required autofocus>
                                    <option selected="selected" value="0">Selecciona jornada</option>
                                     <option value="2">Presencial</option>
                                    <option value="2">Jornada completa</option>
                                    <option value="5">Medio tiempo</option>
                                    <option value="7">Nocturno</option>
                                    <option value="8">Fines de semana</option>
                                     <option value="7">Por horas</option>
                                    <option value="8">Desde casa</option>
                                   
                                  </select>

                                <?php if($errors->has('tipo_jornada')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('tipo_jornada')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
           
    <div class="form-group<?php echo e($errors->has('tipo_contrato') ? ' has-error' : ''); ?>">
                           
                            <div class="col-md-9">
                                 <label for="tipo_contrato" class="text-center">Tipo de contrato</label> 

                                 <select class="form-control" name="tipo_contrato" value="<?php echo e(old('tipo_contrato')); ?>" required autofocus>
                                    <option selected="selected" value="0">Selecciona</option>
                                    <option value="4">Contrato de Aprendizaje</option>
                                    <option value="3">Contrato de obra o labor</option>
                                    <option value="2">Contrato por tiempo determinado</option>
                                    <option value="1">Contrato por tiempo indefinido</option>
                                    <option value="5">Otro tipo de contrato</option>

                                   
                                  </select>

                                <?php if($errors->has('tipo_contrato')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('tipo_contrato')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
           
           
           <div class="form-group<?php echo e($errors->has('tareas') ? ' has-error' : ''); ?>">
                           
                            <div class="col-md-9">
                                 <label for="tareas" class="text-center">Descripcion de las tareas</label> 
                                
                             <textarea rows="4" cols="50" id="tareas" type="text" class="form-control" name="tareas" value="<?php echo e(old('tareas')); ?>" required autofocus>
                                
                                </textarea>
                                <?php if($errors->has('tareas')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('tareas')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
        </div>
     
     
     <div class="form-group<?php echo e($errors->has('salario') ? ' has-error' : ''); ?>">
                           
                            <div class="col-md-9">
                                <label for="salario" class="text-center">Salario (Neto mensual)</label>  
                                <input id="salario" type="text" class="form-control" name="salario" value="<?php echo e(old('salario')); ?>" required autofocus>

                                <?php if($errors->has('salario')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('salario')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>

     
  
     
        






<div class="alert alert-success" role="alert">
        Lugar de trabajo
</div>
     
    <div class="form-group<?php echo e($errors->has('pais2') ? ' has-error' : ''); ?>">
                           
                            <div class="col-md-9">
                                 <label for="pais2" class="text-center">Pais</label> 
<!--                                <input id="pais2" type="text" class="form-control" name="pais2" value="<?php echo e(old('pais2')); ?>" required autofocus>-->
                                 <select class="form-control" name="pais2" value="<?php echo e(old('pais2')); ?>" required autofocus>
                                    <option value="0">Selecciona un país</option>
                                    <option value="10">Argentina</option>
                                    <option value="21">Bolivia</option>
                                    <option value="43">Chile</option>
                                    <option value="48">Colombia</option>
                                    <option value="54">Costa Rica</option>
                                    <option value="56">Cuba</option>
                                    <option value="63">Ecuador</option>
                                    <option value="64">El Salvador</option>
                                    <option value="209">España</option>
                                    <option value="93">Guatemala</option>
                                    <option value="99">Honduras</option>
                                    <option value="139">México</option>
                                    <option value="159">Nicaragua</option>
                                    <option value="171">Panamá</option>
                                    <option value="173">Paraguay</option>
                                    <option value="174">Perú</option>
                                    <option value="181">Puerto Rico</option>
                                    <option value="62">República Dominicana</option>
                                    <option value="243">Uruguay</option>
                                    <option selected="selected" value="245">Venezuela</option>

                                  </select>

                                <?php if($errors->has('pais2')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('pais2')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
     


    <div class="form-group<?php echo e($errors->has('ciudad') ? ' has-error' : ''); ?>">
                           
                            <div class="col-md-9">
                                <label for="ciudad2" class="text-center">Ciudad</label>  
                                <input id="ciudad2" type="text" class="form-control" name="ciudad2" value="<?php echo e(old('ciudad2')); ?>" required autofocus>

                                <?php if($errors->has('ciudad2')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('ciudad2')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
     
     <div class="form-group<?php echo e($errors->has('estado2') ? ' has-error' : ''); ?>">
                          
                            <div class="col-md-9">
                                 <label for="estado2" class="text-center">Estado</label>  
                                <input id="estado2" type="text" class="form-control" name="estado2" value="<?php echo e(old('estado2')); ?>" required autofocus>

                                <?php if($errors->has('estado2')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('estado2')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
     
        
    <div class="alert alert-success" role="alert">
        Requisitos para el cargo
    </div>
           
    <div class="form-group<?php echo e($errors->has('anos_experiencia') ? ' has-error' : ''); ?>">
                           
                            <div class="col-md-9">
                                 <label for="anos_experiencia" class="text-center">Años de experiencia</label> 

                                 <select class="form-control" name="anos_experiencia" value="<?php echo e(old('anos_experiencia')); ?>" required autofocus>
                                    <option value="0">Sin experiencia</option>
                                    <option value="-1">Menos de 1 año</option>
                                    <option value="1">1 año</option>
                                    <option value="2">2 años</option>
                                    <option value="3">3 años</option>
                                    <option value="4">4 años</option>
                                    <option value="5">5 años</option>
                                    <option value="6">6 años</option>
                                    <option value="7">7 años</option>
                                    <option value="8">8 años</option>
                                    <option value="9">9 años</option>
                                    <option value="10">10 años</option>
                                    <option value="11">11 años</option>
                                    <option value="12">12 años</option>
                                    <option value="13">13 años</option>
                                    <option value="14">14 años</option>
                                    <option value="15">15 años</option>


                                   
                                  </select>

                                <?php if($errors->has('anos_experiencia')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('anos_experiencia')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
           
           
    <div class="form-group<?php echo e($errors->has('edad_minima') ? ' has-error' : ''); ?>">
                           
                            <div class="col-md-9">
                                 <label for="edad_minima" class="text-center">Edad minima</label> 

                                 <select class="form-control" name="edad_minima" value="<?php echo e(old('edad_minima')); ?>" required autofocus>
                                    <option value="Edad mínima">Edad mínima</option>
                                    <option value="14">14</option>
                                    <option value="15">15</option>
                                    <option value="16">16</option>
                                    <option value="17">17</option>
                                    <option value="18">18</option>
                                    <option value="19">19</option>
                                    <option value="20">20</option>
                                    <option value="21">21</option>
                                    <option value="22">22</option>
                                    <option value="23">23</option>
                                    <option value="24">24</option>
                                    <option value="25">25</option>
                                    <option value="26">26</option>
                                    <option value="27">27</option>
                                    <option value="28">28</option>
                                    <option value="29">29</option>
                                    <option value="30">30</option>
                                    <option value="31">31</option>
                                    <option value="32">32</option>
                                    <option value="33">33</option>
                                    <option value="34">34</option>
                                    <option value="35">35</option>
                                    <option value="36">36</option>
                                    <option value="37">37</option>
                                    <option value="38">38</option>
                                    <option value="39">39</option>
                                    <option value="40">40</option>
                                    <option value="41">41</option>
                                    <option value="42">42</option>
                                    <option value="43">43</option>
                                    <option value="44">44</option>
                                    <option value="45">45</option>
                                    <option value="46">46</option>
                                    <option value="47">47</option>
                                    <option value="48">48</option>
                                    <option value="49">49</option>
                                    <option value="50">50</option>



                                   
                                  </select>

                                <?php if($errors->has('edad_minima')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('edad_minima')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
           
           
           
    <div class="form-group<?php echo e($errors->has('edad_maxima') ? ' has-error' : ''); ?>">
                           
                            <div class="col-md-9">
                                 <label for="edad_maxima" class="text-center">Edad maxima</label> 

                                 <select class="form-control" name="edad_maxima" value="<?php echo e(old('edad_maxima')); ?>" required autofocus>
                                    <option value="Edad máxima">Edad máxima</option>
                                    <option value="14">14</option>
                                    <option value="15">15</option>
                                    <option value="16">16</option>
                                    <option value="17">17</option>
                                    <option value="18">18</option>
                                    <option value="19">19</option>
                                    <option value="20">20</option>
                                    <option value="21">21</option>
                                    <option value="22">22</option>
                                    <option value="23">23</option>
                                    <option value="24">24</option>
                                    <option value="25">25</option>
                                    <option value="26">26</option>
                                    <option value="27">27</option>
                                    <option value="28">28</option>
                                    <option value="29">29</option>
                                    <option value="30">30</option>
                                    <option value="31">31</option>
                                    <option value="32">32</option>
                                    <option value="33">33</option>
                                    <option value="34">34</option>
                                    <option value="35">35</option>
                                    <option value="36">36</option>
                                    <option value="37">37</option>
                                    <option value="38">38</option>
                                    <option value="39">39</option>
                                    <option value="40">40</option>
                                    <option value="41">41</option>
                                    <option value="42">42</option>
                                    <option value="43">43</option>
                                    <option value="44">44</option>
                                    <option value="45">45</option>
                                    <option value="46">46</option>
                                    <option value="47">47</option>
                                    <option value="48">48</option>
                                    <option value="49">49</option>
                                    <option value="50">50</option>
                                    <option value="51">51</option>
                                    <option value="52">52</option>
                                    <option value="53">53</option>
                                    <option value="54">54</option>
                                    <option value="55">55</option>
                                    <option value="56">56</option>
                                    <option value="57">57</option>
                                    <option value="58">58</option>
                                    <option value="59">59</option>
                                    <option value="60">60</option>
                                    <option value="61">61</option>
                                    <option value="62">62</option>
                                    <option value="63">63</option>
                                    <option value="64">64</option>
                                    <option value="65">65</option>



                                   
                                  </select>

                                <?php if($errors->has('edad_maxima')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('edad_maxima')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
           
    <div class="form-group<?php echo e($errors->has('estudios_minimos') ? ' has-error' : ''); ?>">
                           
                            <div class="col-md-9">
                                 <label for="estudios_minimos" class="text-center">Estudios minimos</label> 

                                 <select class="form-control" name="estudios_minimos" value="<?php echo e(old('estudios_minimos')); ?>" required autofocus>
                                   <option selected="selected" value="0">Selecciona</option>
                                    <option value="1">Educación Básica Primaria</option>
                                    <option value="2">Educación Básica Secundaria</option>
                                    <option value="3">Bachillerato / Educación Media</option>
                                    <option value="4">Educación Técnico/Profesional</option>
                                    <option value="5">Universidad</option>
                                    <option value="6">Postgrado</option>   
                                  </select>

                                <?php if($errors->has('estudios_minimos')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('estudios_minimos')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
           
    <div class="form-group<?php echo e($errors->has('idiomas') ? ' has-error' : ''); ?>">
                           
                            <div class="col-md-9">
                                 <label for="idiomas" class="text-center">Idiomas</label> 

                                 <select class="form-control" name="idiomas" value="<?php echo e(old('idiomas')); ?>" required autofocus>
                                   <option value="47">Español</option>
                                    <option value="77">Inglés</option>
                                    <option value="135">Portugués</option>
                                    <option value="140">Ruso</option>
                                    <option value="184">Árabe</option>
                                    <option value="33">Chino</option>
                                    <option value="55">Francés</option>
                                    <option value="7">Alemán</option>
                                    <option value="28">Catalán</option>
                                    <option value="34">Chuan</option>
                                    <option value="37">Coreano</option>
                                    <option value="46">Esloveno</option>
                                    <option value="82">Italiano</option>
	                            <option value="83">Japonés</option>

 
                                  </select>

                                <?php if($errors->has('idiomas')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('idiomas')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
           
           
    
           
    <div class="form-group<?php echo e($errors->has('idioma_nivel') ? ' has-error' : ''); ?>">
                           
                            <div class="col-md-9">
                                 <label for="idioma_nivel" class="text-center">Idioma nivel</label> 

                                 <select class="form-control" name="idioma_nivel" value="<?php echo e(old('idioma_nivel')); ?>" required autofocus>
                                   <option selected="selected" value="0">Seleccione nivel min.</option>
                                    <option value="1">Muy Básico</option>
                                    <option value="2">Básico</option>
                                    <option value="3">Intermedio</option>
                                    <option value="4">Avanzado</option>
                                    <option value="5">Nativo</option>

                                  </select>

                                <?php if($errors->has('idioma_nivel')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('idioma_nivel')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
           
           
           
    <div class="form-group<?php echo e($errors->has('viajar') ? ' has-error' : ''); ?>">
                           <label for="viajar" class="text-center">viajar</label>  
                            <div class="col-md-9">
                                <label class="radio-inline"><input type="radio" name="viajar" value="si" id="viajar">Si</label>
                               
                                <label class="radio-inline"><input type="radio" name="viajar" value="no" id="viajar">No</label>

                                <?php if($errors->has('viajar')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('viajar')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
           
    <div class="form-group<?php echo e($errors->has('licencia') ? ' has-error' : ''); ?>">
                           <label for="licencia" class="text-center">licencia</label>  
                            <div class="col-md-9">
                                
                               
                                <label class="radio-inline"><input type="radio" name="licencia" value="vehiculos" id="licencia">Vehiculos</label>
                                
                                <label class="radio-inline"><input type="radio" name="licencia" value="camiones" id="licencia">Camiones</label>

                                <?php if($errors->has('licencia')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('licencia')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
           
    
     <p>
 <center><button type="submit" class="btn btn-primary btn-block">Publicar</button></center>
 </p>
     <?php echo Form::close(); ?> 
      </div>
      
   </div>   
      
      
       <?php echo $__env->make('includes.Banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      
      
      
      
      
      
    
  </nav>
     
       
        
        
        
        
        
        </div>
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.myapp4', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>