<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        
    
<?php echo $__env->make('includes.menuIconos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
  
        
 <div class="home-container">
       
        
  
   <?php echo $__env->make('includes.menuLateralPersona', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
     
        
      <div class="central">
          <div class="alert alert-success" role="alert">
             Bienvenidos a la section personal hola bb
          </div> 
   
     </div>
      
      
      
      
      
      
      
   
  
     <?php echo $__env->make('includes.banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>     
       
        
        
    </div>    
        
        
        </div>
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.myapp4', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>