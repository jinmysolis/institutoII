<nav id="menu-lateral">
   <ul class="ul-lateral nav nav-pills">
          <div class="gente">
         <img src="img/profesional.jpg" alt="">
         </div>
       <li <?php if(request()->is('panel')): ?>class="active" <?php endif; ?>><a class="btn btn-lg btn-success text-left" href="<?php echo e(url('/homeEmpresa2')); ?>">
               Empleos<i id="seña"class="fa fa-sign-language fa-fw fa-3x" aria-hidden="true"></i></a></li>
       <li <?php if(request()->is('panel')): ?>class="active" <?php endif; ?>><a class="btn btn-lg btn-success text-left" href="<?php echo e(url('/panel')); ?>">
      Panel<img src="<?php echo e(asset('img/menu-lateral27.png')); ?>" alt="" ></a></li>
      <li><a class="btn btn-lg btn-success text-left" href="#">
      Configuracion<img src="<?php echo e(asset('img/menu-lateral1.png')); ?>" alt="" ></a></li>
      <li <?php if(request()->is('menbresia')): ?>class="active" <?php endif; ?>><a class="btn btn-lg btn-success text-left" href="<?php echo e(url('/menbresia')); ?>">
      Menbresias<img src="<?php echo e(asset('img/menu-lateral2.png')); ?>" alt="" ></a></li>
      <li><a class="btn btn-lg btn-success text-left" href="#">
      Mercado<img src="<?php echo e(asset('img/menu-lateral3.png')); ?>" alt="" ></a></li>
      <li <?php if(request()->is('herramientas')): ?>class="active" <?php endif; ?>><a class="btn btn-lg btn-success text-left" href="<?php echo e(url('/herramientas')); ?>">
      Herramientas<img src="<?php echo e(asset('img/menu-lateral4.png')); ?>" alt="" ></a></li>
      <li <?php if(request()->is('informes')): ?>class="active" <?php endif; ?>><a class="btn btn-lg btn-success text-left" href="<?php echo e(url('/informes')); ?>">
     Informes<img src="<?php echo e(asset('img/menu-lateral5.png')); ?>" alt="" ></a></li>
      <li><a class="btn btn-lg btn-success text-left" href="#">
      Emprendimiento<img src="<?php echo e(asset('img/menu-lateral6.png')); ?>" alt="" ></a></li>
      <li><a class="btn btn-lg btn-success text-left" href="#">
      Certificados<img src="<?php echo e(asset('img/menu-lateral12.png')); ?>" alt="" ></a></li>
      <li><a class="btn btn-lg btn-success text-left" href="#">
     Portafolio<img src="<?php echo e(asset('img/menu-lateral13.png')); ?>" alt="" ></a></li>
     <li><a class="btn btn-lg btn-success text-left" href="#">
     Confianza<img src="<?php echo e(asset('img/menu-lateral15.png')); ?>" alt="" ></a></li>
     <li><a class="btn btn-lg btn-success text-left" href="#">
     Soporte<img src="<?php echo e(asset('img/menu-lateral7.png')); ?>" alt="" ></a></li>
     <li><a class="btn btn-lg btn-success text-left" href="#">
      Galeria<img src="<?php echo e(asset('img/menu-lateral18.png')); ?>" alt="" ></a></li>
      <li><a class="btn btn-lg btn-success text-left" href="#">
     Videos<img src="<?php echo e(asset('img/menu-lateral19.png')); ?>" alt="" ></a></li>
     <li><a class="btn btn-lg btn-success text-left" href="#">
      Biblioteca<img src="<?php echo e(asset('img/menu-lateral20.png')); ?>" alt="" ></a></li>
      <li><a class="btn btn-lg btn-success text-left" href="#">
     Comunidad<img src="<?php echo e(asset('img/menu-lateral21.png')); ?>" alt="" ></a></li>
     <li><a class="btn btn-lg btn-success text-left" href="#">
    Integraciones<img src="<?php echo e(asset('img/menu-lateral9.png')); ?>" alt="" ></a></li>
     <li><a class="btn btn-lg btn-success text-left" href="#">
    Campus virtual<img src="<?php echo e(asset('img/menu-lateral22.png')); ?>" alt="" ></a></li>
    <li><a class="btn btn-lg btn-success text-left" href="#">
     Recursos<img src="<?php echo e(asset('img/menu-lateral23.png')); ?>" alt="" ></a></li>
     <li><a class="btn btn-lg btn-success text-left" href="#">
    Testimonios<img src="<?php echo e(asset('img/menu-lateral10.png')); ?>" alt="" ></a></li>
    <li><a class="btn btn-lg btn-success text-left" href="#">
      Empleos<img src="<?php echo e(asset('img/menu-lateral26.png')); ?>" alt="" ></a></li>
      <li><a class="btn btn-lg btn-success text-left" href="#">
     Visitas<img src="<?php echo e(asset('img/menu-lateral29.png')); ?>" alt="" ></a></li>
      <li><a class="btn btn-lg btn-success text-left" href="#">
    F.A.Q<img src="<?php echo e(asset('img/menu-lateral28.png')); ?>" alt="" ></a></li>
     
     
     
  
      

      </ul>
      
   </nav>

