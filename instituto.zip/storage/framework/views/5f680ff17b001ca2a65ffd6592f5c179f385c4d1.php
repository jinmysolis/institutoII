<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        
    
<?php echo $__env->make('includes.menuIconos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
  
        
 <div class="home-container">
       
   <?php if(auth()->user()->tipoCuenta === 'personal'): ?> 
           <?php echo $__env->make('includes.menuLateralPersona', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
      <?php else: ?>
        
      <?php echo $__env->make('includes.menuLateral', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
        
        
    <?php endif; ?>     
  
   
        
      <div class="central">
          
     <div class="formulario_create_empleo">
          <br><br>
          
 <?php if( session()->has('info')): ?>       
 
     <div class="alert alert-warning" role="alert">
      <?php echo e(session('info')); ?>

     </div>
     
 <?php endif; ?>
          
 <div class="alert alert-success" role="alert">
      Otros conocimientos
 </div>
          <p>
            <div class="text-right">
                <button class="btn btn-success ">
                  Total conomientos: <span class="badge badge-secondary">0</span>
                  <span class="sr-only">unread messages</span>
                </button>
          </div>
          </p>
     <?php echo Form::open(['url'=>'/conocimientos','method'=>'POST']); ?>

      <form  role="form" method="POST" action="<?php echo e(url('/conocimientos')); ?>">
           <?php echo e(csrf_field()); ?>

     
              
             
           
    <div class="form-group<?php echo e($errors->has('titulo') ? ' has-error' : ''); ?>">
                           <label for="titulo" class="text-center">Titulo</label>  
                            <div class="col-md-9">
                                <input id="titulo" type="text" class="form-control" name="titulo" value="<?php echo e(old('titulo')); ?>" required autofocus>

                                <?php if($errors->has('titulo')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('titulo')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
           
           
           

           
           
   <div class="form-group<?php echo e($errors->has('descripcion') ? ' has-error' : ''); ?>">
                           <label for="descripcion" class="text-center">Descripción</label>  
                            <div class="col-md-9">
                                <input id="descripcion" type="text" class="form-control" name="descripcion" value="<?php echo e(old('descripcion')); ?>" required autofocus>

                                <?php if($errors->has('descripcion')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('descripcion')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>        
           
           
                
 
           <hr>
         
           
 <?php if( session()->has('info')): ?>       
 
     <div class="alert alert-warning" role="alert">
      <?php echo e(session('info')); ?>

     </div>
     
 <?php endif; ?>								              
							                 
							               
     
 
  
  <p>
  <center><button type="submit" class="btn btn-primary btn-lg">Registrar</button>
      <a href="<?php echo e(url('/empleos')); ?>" class="btn btn-primary btn-lg">seguir</a>
 
 </p>
     <?php echo Form::close(); ?> 
      </div>
   
</div>
      
      
      
      
      
      
      
   
  
     <?php echo $__env->make('includes.banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>     
       
        
        
    </div>    
        
        
        </div>
    
</div>
<?php $__env->stopSection(); ?>


                  
                  
                
        
                 
               
             
               
             
             
             
              
              

<?php echo $__env->make('layouts.myapp4', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>