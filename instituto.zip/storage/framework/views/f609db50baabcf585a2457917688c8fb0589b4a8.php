 <ul class="ul-show-oferta">
       <a href="<?php echo e(url('/formaciones',Auth::user()->id)); ?>" class="btn btn-success btn-lg">ESTUDIOS</a>
       <a href="<?php echo e(url('/experiencia',Auth::user()->id)); ?>" class="btn btn-success btn-lg">EXPERIENCIAS</a>
       <a href="<?php echo e(url('/conocimientos',Auth::user()->id)); ?>" class="btn btn-success btn-lg">CURSOS</a>
        <a href="<?php echo e(url('/empleos',Auth::user()->id)); ?>" class="btn btn-success btn-lg">INFORMACION</a>
  
    
 </ul>
