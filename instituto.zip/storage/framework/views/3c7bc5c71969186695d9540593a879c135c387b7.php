<nav id="menu-icono">
      <ul >
         
      <li><a class="btn btn-lg btn-success text-left" href="#">
     <img src="<?php echo e(asset('img/late-ico1.png')); ?>" alt="" ></a><div class="text-center"> Candidato</div></li>
      <h1>Aquí encuentras el mejor talento humano.</h1>
      <li><a class="btn btn-lg btn-success text-left" href="<?php echo e(url('/empresas')); ?>">
     <img src="<?php echo e(asset('img/late-ico2.png')); ?>" alt="" ></a> <div class="text-center">Empresa</div></li>
      
      

      </ul>
  
  </nav>