<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.menuIconos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

<div class="home-container">
     <?php if(auth()->user()->tipoCuenta === 'personal'): ?> 
           <?php echo $__env->make('includes.menuLateralPersona', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
      <?php else: ?>
        
      <?php echo $__env->make('includes.menuLateral', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
        
        
    <?php endif; ?>
       
       <div class="central">
            <?php echo $__env->make('includes.menuEmpresaEmpleos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

        <div class="todas">  
            <?php $__currentLoopData = $empleos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                <div class="card" >
                    <img class="card-img-top" src="img/profesional.jpg" alt="Card image cap">
                    <div class="card-block">
                      <h4 class="card-title text-uppercase text-center">Titulo:  <?php echo e($empleo->profesion); ?></h4>
                      <p class="card-text text-uppercase text-center">Descripcion: <?php echo e($empleo->biografia); ?></p>

                      <div class="text-center">
                      <a href="<?php echo e(url('/show2',$empleo->user_id)); ?>" class="btn btn-primary ">leer mas</a>
                      </div>
                    </div>
                </div>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
       </div>
       
          
        </div> 
       
       <?php echo $__env->make('includes.banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>     
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.myapp4', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>