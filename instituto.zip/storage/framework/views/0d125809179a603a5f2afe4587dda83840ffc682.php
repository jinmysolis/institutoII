 <div class="barner">
            
            <img src="<?php echo e(asset('img/barne1.jpg')); ?>">
            <img src="<?php echo e(asset('img/barner2.jpg')); ?>">
            <img src="<?php echo e(asset('img/barner3.jpg')); ?>">
            <img src="<?php echo e(asset('img/barne1.jpg')); ?>">
            <img src="<?php echo e(asset('img/barner2.jpg')); ?>">
            <img src="<?php echo e(asset('img/barner3.jpg')); ?>">
            <img src="<?php echo e(asset('img/barne1.jpg')); ?>">
            <img src="<?php echo e(asset('img/barner2.jpg')); ?>">
            <img src="<?php echo e(asset('img/barner3.jpg')); ?>">
            
            
            
    </div>

