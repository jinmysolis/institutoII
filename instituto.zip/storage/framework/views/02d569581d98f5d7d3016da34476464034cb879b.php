<?php $__env->startSection('content'); ?>
 

<div class="home-container">
    
<div class="central">
   
 <div class="alert alert-success" role="alert">
        Todas las Empresas congeladass
    </div>
<h1></h1>
<div class="center">
    <?php echo e($user->name); ?><br>
    <?php echo e($user->email); ?><br>
    
    <div class="list-group" id="list-group-showOfertas">
         <?php $__currentLoopData = $user->curriculum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curriculum): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <a class="list-group-item color-text" href="#">&nbsp;ID:  <div class="text-center color-text"><?php echo e($curriculum->id); ?></div> </a>
     <a class="list-group-item color-text" href="#">&nbsp;prosefion:  <div class="text-center color-text"><?php echo e($curriculum->profesion); ?></div> </a>
     <a class="list-group-item color-text" href="#">&nbsp;ID:  <div class="text-center color-text"><?php echo e($curriculum->segundo_nombre); ?></div> </a>
     <a class="list-group-item color-text" href="#">&nbsp;prosefion:  <div class="text-center color-text"><?php echo e($curriculum->zona_horaria); ?></div> </a>
     <a class="list-group-item color-text" href="#">&nbsp;ID:  <div class="text-center color-text"><?php echo e($curriculum->idiomas); ?></div> </a>
     <a class="list-group-item color-text" href="#">&nbsp;prosefion:  <div class="text-center color-text"><?php echo e($curriculum->nacionalidad); ?></div> </a>
     <a class="list-group-item color-text" href="#">&nbsp;ID:  <div class="text-center color-text"><?php echo e($curriculum->estado_civil); ?></div> </a>
     <a class="list-group-item color-text" href="#">&nbsp;prosefion:  <div class="text-center color-text"><?php echo e($curriculum->tipo_documento); ?></div> </a>
     <a class="list-group-item color-text" href="#">&nbsp;ID:  <div class="text-center color-text"><?php echo e($curriculum->salario_minimo); ?></div> </a>
     <a class="list-group-item color-text" href="#">&nbsp;prosefion:  <div class="text-center color-text"><?php echo e($curriculum->biografia); ?></div> </a>
   
    <br>
    <hr>
   
    <hr>
    
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
  </div>
   
     <br>
    <hr>
  

 </div>
</div>
    
  <?php echo $__env->make('includes.banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>    
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.myapp4', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>