<?php $__env->startSection('content'); ?>
<h1 class="text-center">Empresas</h1>
 <h1>datos empresas</h1>
<div class="alert alert-success" role="alert">
 Selecciona ahora entre los mejores perfiles que aplican directamente a tus vacantes
</div>
<div class="text-center">
    <button class="btn btn-success">
      Ingenieros <span class="badge badge-secondary">4</span>
    </button>
    <button class="btn btn-success">
      Informatica <span class="badge badge-secondary">7</span>
    </button>
    <button class="btn btn-success">
      Educadores <span class="badge badge-secondary">10</span>
    </button>
    <button class="btn btn-success">
      Licenciados <span class="badge badge-secondary">10</span>
    </button>
    <button class="btn btn-success">
      Doctorados <span class="badge badge-secondary">4</span>
    </button>
    <button class="btn btn-success">
      Contadores<span class="badge badge-secondary">16</span>
    </button>
    <button class="btn btn-success">
     Especialistas <span class="badge badge-secondary">4</span>
    </button>
    <button class="btn btn-success">
      Notifications <span class="badge badge-secondary">4</span>
    </button>
</div>
<br>

<p>
    
    <a href="<?php echo e(url('/empresas/create')); ?>" class="btn btn-primary btn-lg btn-block">Registrate</a>   
    
<button type="button"    class="btn btn-primary btn-lg btn-block">Registra tu empresa ahora!</button>
</p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.myapp4', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>