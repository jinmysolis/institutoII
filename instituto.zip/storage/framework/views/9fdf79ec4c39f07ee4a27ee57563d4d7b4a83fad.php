<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.menuIconos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

<div class="home-container">
      <?php if(auth()->user()->tipoCuenta === 'personal'): ?> 
           <?php echo $__env->make('includes.menuLateralPersona', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
      <?php else: ?>
        
      <?php echo $__env->make('includes.menuLateral', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
        
        
    <?php endif; ?>
       
       <div class="central">
            <?php echo $__env->make('includes.menuEmpresaEmpleos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

          
        <div class="alert alert-success" role="alert">
            <h1>Informacion de contacto</h1>
<div class="list-group" id="list-group-showOfertas">
    <?php $__currentLoopData = $usuario->curriculum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

    <a class="list-group-item color-text" href="#">&nbsp;PROFESION:  <div class="text-center color-text"><?php echo e($usuario->profesion); ?></div> </a>
    <a class="list-group-item color-text" href="#">&nbsp;SEGUNDO NOMBRE:  <div class="text-center color-text"><?php echo e($usuario->segundo_nombre); ?></div> </a>
    <a class="list-group-item color-text" href="#">&nbsp;ZONA HORARIA:  <div class="text-center color-text"><?php echo e($usuario->zona_horaria); ?></div> </a>
    <a class="list-group-item color-text" href="#">&nbsp;IDIOMAS:  <div class="text-center color-text"><?php echo e($usuario->idiomas); ?></div> </a>
    <a class="list-group-item color-text" href="#">&nbsp;NACIONALIDAD:  <div class="text-center color-text"><?php echo e($usuario->nacionalidad); ?></div> </a>
    <a class="list-group-item color-text" href="#">&nbsp;ESTADO CIVIL:  <div class="text-center color-text"><?php echo e($usuario->estado_civil); ?></div> </a>
    <a class="list-group-item color-text" href="#">&nbsp;CEDULA:  <div class="text-center color-text"><?php echo e($usuario->cedula_ciudadania); ?></div> </a>
    <a class="list-group-item color-text" href="#">&nbsp;LICENCIA:  <div class="text-center color-text"><?php echo e($usuario->licencia); ?></div> </a>
    <a class="list-group-item color-text" href="#">&nbsp;FECHA DE NACIMIENTO:  <div class="text-center color-text"><?php echo e($usuario->fecha_nacimiento); ?></div> </a>
    <a class="list-group-item color-text" href="#">&nbsp;LUGAR DE NACIMIENTO:  <div class="text-center color-text"><?php echo e($usuario->lugar_nacimiento); ?></div> </a>
    <a class="list-group-item color-text" href="#">&nbsp;PAIS DE RESIDENCIA:  <div class="text-center color-text"><?php echo e($usuario->pais_residencia); ?></div> </a>
    
    <a class="list-group-item color-text" href="#">&nbsp;CIUDAD:  <div class="text-center color-text"><?php echo e($usuario->ciudad); ?></div> </a>
    <a class="list-group-item color-text" href="#">&nbsp;CODIGO TELEFONO:  <div class="text-center color-text"><?php echo e($usuario->codigo_telefono); ?></div> </a>
    <a class="list-group-item color-text" href="#">&nbsp;TELEFONO:  <div class="text-center color-text"><?php echo e($usuario->telefono); ?></div> </a>
    <a class="list-group-item color-text" href="#">&nbsp;SALARIO ACEPTADO:  <div class="text-center color-text"><?php echo e($usuario->salario_minimo); ?></div> </a>
    <a class="list-group-item color-text" href="#">&nbsp;RIF-NIT-ISS:  <div class="text-center color-text"><?php echo e($usuario->rif_nit_iss); ?></div> </a>
    <a class="list-group-item color-text" href="#">&nbsp;GENERO:  <div class="text-center color-text"><?php echo e($usuario->genero); ?></div> </a>
    
    
    
    <ul class="ul-show-oferta">
                         
       <a href="<?php echo e(url('/showFormacion',$usuario->user_id)); ?>" class="btn btn-success btn-lg">ESTUDIOS</a>
       <a href="<?php echo e(url('/showExperiencia',$usuario->user_id)); ?>" class="btn btn-success btn-lg">EXPERIENCIAS</a>
       <a href="<?php echo e(url('/showConocimientos',$usuario->user_id)); ?>" class="btn btn-success btn-lg">CURSOS</a>
   
    
    </ul>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
  

</div>
 


             
</div>
       
                          <form>
                            
                              <input type="button" value="volver atrás" name="volver atrás2" onclick="history.back()" class="btn btn-success btn-lg"/>
                            
                          </form>
          
        </div> 
       
       <?php echo $__env->make('includes.banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>     
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.myapp4', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>