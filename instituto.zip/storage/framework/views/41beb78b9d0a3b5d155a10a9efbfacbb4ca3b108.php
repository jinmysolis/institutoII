<?php $__env->startSection('content'); ?>


<!--    <?php echo $__env->make('includes.menuIconosEmpleo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> -->
    
    <h1>mostar empleos publicados por empresas</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.myapp4', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>