<?php $__env->startSection('content'); ?>

<!--<?php echo $__env->make('includes.menuEmpresaEmpleos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  -->

 
<h1>Detalles de la Oferta</h1>
<div class="list-group" id="list-group-showOfertas">
    <a class="list-group-item color-text" href="#"><i class="fa fa-users fa-fw fa-3x" aria-hidden="true"></i>&nbsp;AREA:  <div class="text-center color-text"><?php echo e($pempresa->area); ?></div> </a>
    <a class="list-group-item color-text" href="#"><i class="fa fa-american-sign-language-interpreting fa-fw fa-3x" aria-hidden="true"></i>&nbsp;Tipo de Contrato <div class="text-center color-text"><?php echo e($pempresa->tipo_contrato); ?></div></a>
     <a class="list-group-item color-text" href="#"><i class="fa fa-pencil fa-fw fa-3x" aria-hidden="true"></i>&nbsp;Tipo de jornada <div class="text-center color-text"><?php echo e($pempresa->tipo_jornada); ?></div></a>
    <a class="list-group-item color-text" href="#"><i class="fa fa-graduation-cap fa-fw fa-3x" aria-hidden="true"></i>&nbsp; Estudios <div class="text-center color-text"><?php echo e($pempresa->estudios_minimos); ?></div></a>
    <a class="list-group-item color-text" href="#"><i class="fa fa-history fa-fw fa-3x" aria-hidden="true"></i>&nbsp; Experiencia <div class="text-center color-text"><?php echo e($pempresa->anos_experiencia); ?> AÑOS</div></a>
  

</div>
<ul class="ul-show-oferta">
    <li class="li-show-oferta">SALARIO<div><?php echo e($pempresa->salario); ?></div></li>
    <li class="li-show-oferta">PAIS<div><?php echo e($pempresa->pais2); ?></div></li>
    <li class="li-show-oferta">CIUDAD<div><?php echo e($pempresa->ciudad2); ?></div></li>
    <li class="li-show-oferta">ESTADO<div><?php echo e($pempresa->estado2); ?></div></li>
    <li class="li-show-oferta">EDAD-MINIMA<div><?php echo e($pempresa->edad_minima); ?>AÑOS</div></li>
    <li class="li-show-oferta">EDAD-MAXIMA<div><?php echo e($pempresa->edad_maxima); ?>AÑOS</div></li>
    <li class="li-show-oferta">IDIOMA<div><?php echo e($pempresa->idiomas); ?></div></li>
    <li class="li-show-oferta">NIVEL<div><?php echo e($pempresa->idioma_nivel); ?></div></li>
    <li class="li-show-oferta">VIAJAR<div><?php echo e($pempresa->viajar); ?></div></li>
    <li class="li-show-oferta">LICENCIA<div><?php echo e($pempresa->licencia); ?></div></li>
 </ul>
<div class="list-group" id="list-group-showOfertas">
    <a class="list-group-item color-text" href="#"><i class="fa fa-lightbulb-o fa-fw fa-3x" aria-hidden="true"></i>&nbsp;FUNCIONES PRINCIPALES::  <div class="text-left color-text"><?php echo e($pempresa->tareas); ?></div> </a>
    
  

</div>
<div class="text-center">       
   <a href="<?php echo e(url('/publicarOferta')); ?>"class="btn btn-success ">Regresar</a>
 </div>            

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.myapp4', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>