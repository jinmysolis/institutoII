<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.menuIconos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

<div class="home-container">
    
    
 <?php echo $__env->make('includes.menuLateral', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>    
    
    <div class="central">   
<h1>aqui van las ofertas de las compañias que necesitan empleados</h1>

  
    <div class="row text-center" id="row-pempresa">
    
    <?php $__empty_1 = true; $__currentLoopData = $pempresa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pempresa): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
      <div class="col-6">
      <div class="text-center">

        
           
    <section class="cta img-thumbnail">
      <div class="container">
        <div class="row">
          <div class="col-lg-9 col-sm-6 text-lg-left text-center">
            <h2>
               <span class="span-pempresa">Se solicita: </span>  <?php echo e($pempresa->titulo_oferta); ?>

            </h2>

              <p id="span-pempresa-container">
                <span class="span-pempresa">Funciones: </span><?php echo e($pempresa->tareas); ?><br>
                <span class="span-pempresa">Resposable: </span><?php echo e($pempresa->user->name); ?><br>
                <span class="span-pempresa">Fecha: </span><?php echo e($pempresa->created_at); ?>

            </p>
            <a class="btn btn-ghost" href="<?php echo e(url('/publicarOferta',$pempresa->id)); ?>">Mas informacion</a>
          </div>

          
        </div>
      </div>
    </section>
        
        

        <hr>
            
        
      </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
    <p>No hay mensajes destacados</p>
    <?php endif; ?>
   </div>  
    
</div>
    <?php echo $__env->make('includes.banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.myapp4', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>