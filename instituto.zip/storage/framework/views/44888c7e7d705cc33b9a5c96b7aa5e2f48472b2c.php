<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        
<?php echo $__env->make('includes.menuIconos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

<div class="home-container">
    
    
 <?php if(auth()->user()->tipoCuenta === 'personal'): ?> 
           <?php echo $__env->make('includes.menuLateralPersona', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
      <?php else: ?>
        
      <?php echo $__env->make('includes.menuLateral', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
        
        
    <?php endif; ?>
    
    <div class="central">   
   
   
   <h1>aqui van las ofertas de las compañias que necesitan empleados </h1>
   <?php if( session()->has('info')): ?>       
    <div class="alert alert-success" role="alert">
    <?php echo e(session('info')); ?>

     </div>
   <?php endif; ?>
   
   
   <?php $__empty_1 = true; $__currentLoopData = $pempresa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pempresa): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
     
      

        
           
    <section class="cta img-thumbnail">
      <div class="contai">
        <div class="row-contai">
          <div class="row-contai-cont">
            <h2>
               <span class="span-pempresa">Se solicita: </span>  <?php echo e($pempresa->titulo_oferta); ?>

            </h2>

              <p id="span-pempresa-container">
                <span class="span-pempresa">Funciones: </span><?php echo e($pempresa->tareas); ?><br>
                <span class="span-pempresa">Resposable: </span><?php echo e($pempresa->user->name); ?><br>
                <span class="span-pempresa">Fecha: </span><?php echo e($pempresa->created_at); ?>

              </p>
              
              <div class="row-contai-cont-a">
            <a class="btn btn-ghost" href="<?php echo e(url('/publicarOferta',$pempresa->id)); ?>">Mas informacion</a>
            <a class="btn btn-ghost" href="<?php echo e(url('/postular',$pempresa->user_id)); ?>">postularte</a>
            </div>
          </div>

          
        </div>
      </div>
    </section>
        
        

        <hr>
            
        
     
      
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
    <p>No hay mensajes destacados</p>
    <?php endif; ?>
    
   </div>
    
    
    <?php echo $__env->make('includes.banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>    


</div></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.myapp4', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>