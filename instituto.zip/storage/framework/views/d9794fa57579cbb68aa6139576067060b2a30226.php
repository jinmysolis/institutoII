<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.menuIconos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 


<div class="home-container">
    <?php if(auth()->user()->tipoCuenta === 'personal'): ?> 
           <?php echo $__env->make('includes.menuLateralPersona', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
      <?php else: ?>
        
      <?php echo $__env->make('includes.menuLateral', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
        
        
    <?php endif; ?>
       
       <div class="central">
            <?php echo $__env->make('includes.menuEmpleosCurriculum', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

           <div class="alert alert-success" role="alert">
            <h1>Experiencia laboral</h1>
<div class="list-group" id="list-group-showOfertas">
    
    <?php $__currentLoopData = $user->experiencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experiencia): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <a class="list-group-item color-text" href="#">&nbsp;NOMBRE DE LA EMPRESA:  <div class="text-center color-text"><?php echo e($experiencia->nombre_empresa); ?></div> </a>
    <a class="list-group-item color-text" href="#">&nbsp;ACTIVIDAS DE LA EMPRESA:  <div class="text-center color-text"><?php echo e($experiencia->actividad_empresa); ?></div> </a>
    <a class="list-group-item color-text" href="#">&nbsp;PUESTO DESEMPEÑADO:  <div class="text-center color-text"><?php echo e($experiencia->puesto); ?></div> </a>
    <a class="list-group-item color-text" href="#">&nbsp;NIVEL DE EXPERIENCIA:   <div class="text-center color-text"><?php echo e($experiencia->nivel_experiencia); ?></div> </a>
    <a class="list-group-item color-text" href="#">&nbsp;PAIS DE TRABAJO: <div class="text-center color-text"><?php echo e($experiencia->pais); ?></div> </a>
    <a class="list-group-item color-text" href="#">&nbsp;DESCRIPCION DE PUESTO DE TRABAJO: <div class="text-center color-text"><?php echo e($experiencia->descripcion_puesto); ?></div> </a>
    <a class="list-group-item color-text" href="#">&nbsp;DESDE:   <div class="text-center color-text"><?php echo e($experiencia->ano_inicio_trabajo); ?></div> </a>
    <a class="list-group-item color-text" href="#">&nbsp;HASTA: <div class="text-center color-text"><?php echo e($experiencia->ano_fin_trabajo); ?></div> </a>
    <h1 STYLE="font-size:18px; font-family:arial; color:#fff">Experiencia laboral</h1>
    <hr>
    
     <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    
  

</div>
                         


             
         </div>
        
                         <form>
                            
                              <input type="button" value="volver atrás" name="volver atrás2" onclick="history.back()" class="btn btn-success btn-lg"/>
                            
                          </form>
       
          
        </div> 
       
       <?php echo $__env->make('includes.banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>     
    
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.myapp4', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>