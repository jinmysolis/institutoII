<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        
    
<?php echo $__env->make('includes.menuIconos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
  
        
 <div class="home-container">
       
        
  
   <?php echo $__env->make('includes.menuLateral', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
        
        
      <div class="central">
          
     <div class="formulario_create_empleo">
          <br><br>
 
     <?php echo Form::open(['url'=>'/empleos','method'=>'POST']); ?>

      <form  role="form" method="POST" action="<?php echo e(url('/empleos')); ?>">
           <?php echo e(csrf_field()); ?>

     <div class="form-group<?php echo e($errors->has('primer_nombre') ? ' has-error' : ''); ?>">
                           <label for="primer_nombre" class="text-center">Primer nombre</label>  
                            <div class="col-md-9">
                                <input id="primer_nombre" type="text" class="form-control" name="primer_nombre" value="<?php echo e(old('primer_nombre')); ?>" required autofocus>

                                <?php if($errors->has('primer_nombre')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('primer_nombre')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
     
     <div class="form-group<?php echo e($errors->has('segundo_nombre') ? ' has-error' : ''); ?>">
                           <label for="segundo_nombre" class="text-center">Segundo nombre</label>  
                            <div class="col-md-9">
                                <input id="segundo_nombre" type="text" class="form-control" name="segundo_nombre" value="<?php echo e(old('segundo_nombre')); ?>" required autofocus>

                                <?php if($errors->has('segundo_nombre')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('segundo_nombre')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
     
     
     <div class="form-group<?php echo e($errors->has('apellidos') ? ' has-error' : ''); ?>">
                           <label for="apellidos" class="text-center">Apellidos</label>  
                            <div class="col-md-9">
                                <input id="apellidos" type="text" class="form-control" name="apellidos" value="<?php echo e(old('apellidos')); ?>" required autofocus>

                                <?php if($errors->has('apellidos')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('apellidos')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
     
     <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                           <label for="email" class="text-center">email</label>  
                            <div class="col-md-9">
                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
     
     <div class="form-group<?php echo e($errors->has('cargo_que_busca') ? ' has-error' : ''); ?>">
                           <label for="cargo_que_busca" class="text-center">Cargo que busca</label>  
                            <div class="col-md-9">
                                <input id="cargo_que_busca" type="text" class="form-control" name="cargo_que_busca" value="<?php echo e(old('cargo_que_busca')); ?>" required autofocus>

                                <?php if($errors->has('cargo_que_busca')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('cargo_que_busca')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
     
     <div class="form-group<?php echo e($errors->has('salario_minimo') ? ' has-error' : ''); ?>">
                           <label for="salario_minimo" class="text-center">Salario minimo</label>  
                            <div class="col-md-9">
                                <input id="salario_minimo" type="number" class="form-control" name="salario_minimo" value="<?php echo e(old('salario_minimo')); ?>" required autofocus>

                                <?php if($errors->has('salario_minimo')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('salario_minimo')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
     
     <div class="form-group<?php echo e($errors->has('fecha_nacimiento') ? ' has-error' : ''); ?>">
                           <label for="fecha_nacimiento" class="text-center">Fecha nacimiento</label>  
                            <div class="col-md-9">
                                <input id="fecha_nacimiento" type="date" class="form-control" name="fecha_nacimiento" value="<?php echo e(old('fecha_nacimiento')); ?>" required autofocus>
                                   
                                <?php if($errors->has('fecha_nacimiento')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('fecha_nacimiento')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
     
     <div class="form-group<?php echo e($errors->has('cedula_pasaporte') ? ' has-error' : ''); ?>">
         <label for="cedula_pasaporte" id="label-cedula"class="text-center">Cedula o pasaporte</label>  
                           <div class="col-md-9" id="cedula">
                                <input id="prefijo_cedula" type="text" class="form-control" name="prefijo_cedula" value="<?php echo e(old('prefijo_cedula')); ?>" required autofocus>
                                <input id="cedula_pasaporte" type="text" class="form-control text-right" name="cedula_pasaporte" value="<?php echo e(old('cedula_pasaporte')); ?>" required autofocus>
                                <?php if($errors->has('cedula_pasaporte')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('cedula_pasaporte')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
     
     <div class="form-group<?php echo e($errors->has('rif_nit_iss') ? ' has-error' : ''); ?>">
                           <label for="rif_nit_iss" class="text-center">Rif, Nit, ISS</label>  
                            <div class="col-md-9">
                                <input id="rif_nit_iss" type="number" class="form-control" name="rif_nit_iss" value="<?php echo e(old('rif_nit_iss')); ?>" required autofocus>

                                <?php if($errors->has('rif_nit_iss')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('rif_nit_iss')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
     
     <div class="form-group<?php echo e($errors->has('telefono_residencia') ? ' has-error' : ''); ?>">
                           <label for="telefono_residencia" class="text-center">Telf residencia</label>  
                            <div class="col-md-9">
                                <input id="telefono_residencia" type="number" class="form-control" name="telefono_residencia" value="<?php echo e(old('telefono_residencia')); ?>" required autofocus>

                                <?php if($errors->has('telefono_residencia')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('telefono_residencia')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
     
     <div class="form-group<?php echo e($errors->has('telefono_movil') ? ' has-error' : ''); ?>">
                           <label for="telefono_movil" class="text-center">Telefono movil</label>  
                           <div class="col-md-9" id="movil">
                                <input id="prefijo_movil" type="text" class="form-control" name="prefijo_movil" value="<?php echo e(old('prefijo_movil')); ?>" required autofocus>
                                <input id="telefono_movil" type="number" class="form-control" name="telefono_movil" value="<?php echo e(old('telefono_movil')); ?>" required autofocus>

                                <?php if($errors->has('telefono_movil')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('telefono_movil')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
     
     <div class="form-group<?php echo e($errors->has('telefono_oficina') ? ' has-error' : ''); ?>">
                           <label for="telefono_oficina" class="text-center">Telefono oficina</label>  
                           <div class="col-md-9" id="oficina">
                                 <input id="prefijo_oficina" type="text" class="form-control" name="prefijo_oficina" value="<?php echo e(old('prefijo_oficina')); ?>" required autofocus>
                                <input id="telefono_oficina" type="number" class="form-control" name="telefono_oficina" value="<?php echo e(old('telefono_oficina')); ?>" required autofocus>

                                <?php if($errors->has('telefono_oficina')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('telefono_oficina')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
     
     <div class="form-group<?php echo e($errors->has('pais') ? ' has-error' : ''); ?>">
                           <label for="pais" class="text-center">Pais</label>  
                            <div class="col-md-9">
                                <input id="pais" type="text" class="form-control" name="pais" value="<?php echo e(old('pais')); ?>" required autofocus>

                                <?php if($errors->has('pais')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('pais')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
     
     <div class="form-group<?php echo e($errors->has('estado') ? ' has-error' : ''); ?>">
                           <label for="estado" class="text-center">Estado</label>  
                            <div class="col-md-9">
                                <input id="estado" type="text" class="form-control" name="estado" value="<?php echo e(old('estado')); ?>" required autofocus>

                                <?php if($errors->has('estado')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('estado')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
     
     
     <div class="form-group<?php echo e($errors->has('ciudad') ? ' has-error' : ''); ?>">
                           <label for="ciudad" class="text-center">Ciudad</label>  
                            <div class="col-md-9">
                                <input id="ciudad" type="text" class="form-control" name="ciudad" value="<?php echo e(old('ciudad')); ?>" required autofocus>

                                <?php if($errors->has('ciudad')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('ciudad')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
     
     <div class="form-group<?php echo e($errors->has('estado_civil') ? ' has-error' : ''); ?>">
                           <label for="estado_civil" class="text-center">Estado civil</label>  
                            <div class="col-md-9">
                                <label class="radio-inline"><input type="radio" name="estado_civil" value="casado" id="estado_civil">Casado</label>
                                <label class="radio-inline"><input type="radio" name="estado_civil" value="viudo" id="estado_civil">Viudo</label>
              
                                <label class="radio-inline"><input type="radio" name="estado_civil" value="soltero" id="estado_civil">Soltero</label>
                                <label class="radio-inline"><input type="radio" name="estado_civil" value="separado" id="estado_civil">Separado</label>

                                <?php if($errors->has('estado_civil')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('estado_civil')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>

<div id=""class="text-center">
                                     
                            <label class="radio-inline"><input type="radio" name="genero" value="hombre" id="genero">Hombre</label>
                            <label class="radio-inline"><input type="radio" name="genero" value="mujer" id="genero">mujer</label>
                            
                            </div>
     
     <div class="form-group<?php echo e($errors->has('genero') ? ' has-error' : ''); ?>">
                           <label for="genero" class="text-center">Genero</label>  
                            <div class="col-md-9">
                                <label class="radio-inline"><input type="radio" name="genero" value="hombre" id="genero">Hombre</label>
                               
                                <label class="radio-inline"><input type="radio" name="genero" value="mujer" id="genero">Mujer</label>

                                <?php if($errors->has('genero')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('genero')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
     
      <div class="form-group<?php echo e($errors->has('profesion') ? ' has-error' : ''); ?>">
                           <label for="profesion" class="text-center">Titulo profesional</label>  
                            <div class="col-md-9">
                                <input id="profesion" type="text" class="form-control" name="profesion" value="<?php echo e(old('profesion')); ?>" required autofocus>

                                <?php if($errors->has('profesion')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('profesion')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
    </div>
     
    
  
    
  
   
  
     <p>
 <center><button type="submit" class="btn btn-primary btn-lg">Registrar</button></center>
 </p>
     <?php echo Form::close(); ?> 
      </div>
   
</div>
      
      
      
      
      
      
      
   
  
     <?php echo $__env->make('includes.banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>     
       
        
        
    </div>    
        
        
        </div>
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.myapp4', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>