<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.menuIconos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
  

<div class="home-container">
     <?php echo $__env->make('includes.menuLateral', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
<div class="central">
    <?php echo $__env->make('includes.menuEmpresaEmpleos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <div class="alert alert-success" role="alert">
        Todas los empleos publicados
    </div>
<h1></h1>
<div class="center">
    <?php echo e($user->name); ?><br>
    
    <div class="list-group" id="list-group-showOfertas">
         <?php $__currentLoopData = $user->empleos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<a class="list-group-item color-text" href="#">&nbsp;TITULO:  <div class="text-center color-text"> <?php echo e($empleo->titulo_oferta); ?></div> </a>
<a class="list-group-item color-text" href="#">&nbsp;AREA:  <div class="text-center color-text"> <?php echo e($empleo->area); ?></div> </a>
<a class="list-group-item color-text" href="#">&nbsp;Tipo de Contrato <div class="text-center color-text"><?php echo e($empleo->tipo_contrato); ?></div></a>
<a class="list-group-item color-text" href="#">&nbsp;Tipo de jornada <div class="text-center color-text"><?php echo e($empleo->
tipo_jornada); ?></div></a>
<a class="list-group-item color-text" href="#">&nbsp; Estudios <div class="text-center color-text"> <?php echo e($empleo->estudios_minimos); ?></div></a>
<a class="list-group-item color-text" href="#">&nbsp; Experiencia <div class="text-center color-text"> <?php echo e($empleo->anos_experiencia); ?> AÑOS</div></a>
<a class="list-group-item color-text" href="#">&nbsp; TAREAS <div class="text-center color-text"> <?php echo e($empleo->tareas); ?></div></a>
<a class="list-group-item color-text" href="#">&nbsp; SALARIO <div class="text-center color-text"> <?php echo e($empleo->salario); ?></div></a>
<a class="list-group-item color-text" href="#">&nbsp; PAIS <div class="text-center color-text"> <?php echo e($empleo->pais2); ?></div></a>
<a class="list-group-item color-text" href="#">&nbsp; CIUDAD <div class="text-center color-text"> <?php echo e($empleo->ciudad2); ?></div></a>
<a class="list-group-item color-text" href="#">&nbsp; ESTADO <div class="text-center color-text"> <?php echo e($empleo->estado2); ?></div></a>
<a class="list-group-item color-text" href="#">&nbsp; EDAD MINIMA <div class="text-center color-text"> <?php echo e($empleo->edad_minima); ?></div></a>

  <a class="list-group-item color-text" href="#">&nbsp; EDAD MAXIMA <div class="text-center color-text"> <?php echo e($empleo->edad_maxima); ?></div></a>
<a class="list-group-item color-text" href="#">&nbsp; IDIOMAS <div class="text-center color-text"> <?php echo e($empleo->idiomas); ?></div></a>
<a class="list-group-item color-text" href="#">&nbsp; NIVEL IDIOMA <div class="text-center color-text"> <?php echo e($empleo->idioma_nivel); ?></div></a>
<a class="list-group-item color-text" href="#">&nbsp; VIAJAR <div class="text-center color-text">  <?php echo e($empleo->viajar); ?></div></a>
<a class="list-group-item color-text" href="#">&nbsp; LICENCIA <div class="text-center color-text">  <?php echo e($empleo->licencia); ?></div></a>         
           
            
            
    <br>
    <hr>
    <a class="list-group-item color-text" href="#">&nbsp;EMPLEOS PUBLICADOS:  </a>
    <hr>       
           
            
            
           
    
     <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
  </div>
   
     <br>
    <hr>
  

 </div>
</div>
    
  <?php echo $__env->make('includes.banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>    
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.myapp4', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>