@extends('layouts.myapp4')

@section('content')
<div class="container-fluid">
    <div class="row">
        
    
@include('includes.menuIconos')  
  
        
 <div class="home-container">
       
       
  
   @include('includes.menuLateral')  
        
        
      <div class="central">
       <div class="alert alert-success" role="alert">
             Bienvenidos a la seccion empresa
      </div>   
          <a href="{{ url('/empresas/create') }}" class="btn alert-success">Publicar-empleo</a>
   
      </div>
      
      
      
      
      
      
      
   
  
     @include('includes.banner')     
       
        
        
    </div>    
        
        
        </div>
    
</div>
@endsection
