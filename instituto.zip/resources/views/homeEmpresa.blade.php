@extends('layouts.myapp4')

@section('content')
<div class="container-fluid">
    <div class="row">
        
    
@include('includes.menuIconos')  
  
        
 <div class="home-container">
       
       
  
   @include('includes.menuLateral')  
        
        
      <div class="central">
<!--       @include('includes.menuEmpresaEmpleos') -->
   
      </div>
      
      
      
      
      
      
      
   
  
     @include('includes.banner')     
       
        
        
    </div>    
        
        
        </div>
    
</div>
@endsection
