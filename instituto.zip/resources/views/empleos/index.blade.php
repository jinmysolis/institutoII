@extends('layouts.myapp4')

@section('content')


<!--    @include('includes.menuIconosEmpleo') -->
    
   <div class="alert alert-success" role="alert">
     Aqui se mostraran  los curriculum inscriptos
 </div>

@endsection