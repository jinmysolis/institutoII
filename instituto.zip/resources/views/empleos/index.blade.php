@extends('layouts.myapp4')

@section('content')


    @include('includes.menuIconosEmpleo') 
    
    <h1>datos persona</h1>

@endsection