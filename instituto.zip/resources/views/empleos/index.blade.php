@extends('layouts.myapp4')

@section('content')


<!--    @include('includes.menuIconosEmpleo') -->
    
    <h1>mostar empleos publicados por empresas</h1>

@endsection