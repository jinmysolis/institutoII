@extends('layouts.myapp4')

@section('content')

 
@include('includes.menuEmpresaEmpleos') 

    
      
      
     
       
        
   
        
        
       
@endsection