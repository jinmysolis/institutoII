<!DOCTYPE html>

<html lang="es">
    <hed>
        <meta charset="UTF-8">
        <title>Mesajae recibido</title>
    </hed>
    
    <body>
        
        
        
       
        
        <h1>hola estos son los datos del currieculum</h1>
        <h1>correo del usuario que se postula: {{$us->email}}</h1>
        <h2>Nombre usuario registrado: {{$us['name']}}</h2>
        <h3>tipo de cuenta: {{$us['tipoCuenta']}}</h3>
        
        <hr>
        <h1>Informacion personal</h1>
        
        <div class="alert alert-success" role="alert">
        Informacion personal
        </div>
        
        <div class="alert alert-success" role="alert">
       
        @foreach($us->curriculum as $u)
           
            profesion:{{$u->profesion}}<br>
            Segundo nombre: {{$u->segundo_nombre}}<br>
            Zona horaria {{$u->zona_horaria}}<br>
            Idiomas:{{$u->idiomas}}<br>
            Nacionalidad: {{$u->nacionalidad}}<br>
            Estado civil {{$u->estado_civil}}<br>
            Cedula:{{$u->cedula_ciudadania}}<br>
            Licencia: {{$u->licencia}}<br>
            Fecha de nacimiento: {{$u->fecha_nacimiento}}<br>
            Lugar de nacimiento:{{$u->lugar_nacimiento}}<br>
            Pais de residencia: {{$u->pais_residencia}}<br>
            Ciudad{{$u->ciudad}}<br>
            Biografia:{{$u->biografia}}<br>
            Codigo Telefono{{$u->codigo_telefono}}<br>
            Numero detelefono{{$u->telefono}}<br>
            Salario aceptado:{{$u->salario_minimo}}<br>
            Rif-Nit-Iss: {{$u->rif_nit_iss}}<br>
            Genero: {{$u->genero}}<br>
            
            <br><hr>
            <a href="{{ url('/empleos',$u->id) }}"><h1>Mas informacion</h1> </a>
           <hr>
         @endforeach
         
        </div>
        
        
        
<!--        <div class="alert alert-success" role="alert">
       
        @foreach($us->formacion as $u)
           
            profesion:{{$u->centro_educativo_primaria}}<br>
            Segundo nombre: {{$u->estado_primaria}}<br>
            Zona horaria {{$u->ano_inicio_primaria}}<br>
            Idiomas:{{$u->ano_fin_primaria}}<br>
            Nacionalidad: {{$u->centro_educativo_secundaria}}<br>
            Estado civil {{$u->estado_secundaria}}<br>
            Cedula:{{$u->ano_inicio_secundaria}}<br>
            Licencia: {{$u->ano_fin_secundaria}}<br>
            Fecha de nacimiento: {{$u->centro_educativo_universidad}}<br>
            Lugar de nacimiento:{{$u->estado_universidad}}<br>
            Pais de residencia: {{$u->ano_inicio_universidad}}<br>
            Ciudad{{$u->ano_fin_universidad}}<br>
            Biografia:{{$u->centro_educativo_posgrado}}<br>
            Codigo Telefono{{$u->estado_posgrado}}<br>
            Numero detelefono{{$u->ano_inicio_posgrado}}<br>
            Salario aceptado:{{$u->ano_fin_posgrado}}<br>
           
           
         @endforeach
         
        </div>-->
        
    </body>
</html>