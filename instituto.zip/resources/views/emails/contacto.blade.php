<!DOCTYPE html>

<html lang="es">
    <hed>
        <meta charset="UTF-8">
        <title>Mesajae recibido</title>
    </hed>
    
    <body>
        <h1>correo usuario registrado: {{$msg['email']}}</h1>
        <h2>Nombre usuario registrado: {{$msg['name']}}</h2>
        <h3>tipo de cuenta: {{$msg['tipoCuenta']}}</h3>
        
        
    </body>
</html>