 <div class="barner">
            
            <img src="{{ asset('img/barne1.jpg') }}">
            <img src="{{ asset('img/barner2.jpg') }}">
            <img src="{{ asset('img/barner3.jpg') }}">
            <img src="{{ asset('img/barne1.jpg') }}">
            <img src="{{ asset('img/barner2.jpg') }}">
            <img src="{{ asset('img/barner3.jpg') }}">
            <img src="{{ asset('img/barne1.jpg') }}">
            <img src="{{ asset('img/barner2.jpg') }}">
            <img src="{{ asset('img/barner3.jpg') }}">
            
            
            
    </div>

