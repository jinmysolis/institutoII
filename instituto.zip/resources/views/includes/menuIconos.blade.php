<nav id="menu-icono">
      <ul >
         
      <li><a class="btn btn-lg btn-success text-left" href="#">
     <img src="{{ asset('img/late-ico1.png') }}" alt="" ></a><div class="text-center"> Cuenta</div></li>
      <li><a class="btn btn-lg btn-success text-left" href="#">
     <img src="{{ asset('img/late-ico2.png') }}" alt="" ></a> <div class="text-center">Personal</div></li>
      <li><a class="btn btn-lg btn-success text-left" href="#">
     <img src="{{ asset('img/late-ico3.png') }}" alt="" ></a> <div class="text-center">Empresa</div></li>
      <li><a class="btn btn-lg btn-success text-left" href="#">
     <img src="{{ asset('img/late-ico4.png') }}" alt="" ></a><div class="text-center"> Habilidades</div></li>
      <li><a class="btn btn-lg btn-success text-left" href="#">
     <img src="{{ asset('img/late-ico5.png') }}" alt="" ></a><div class="text-center"> Finanzas</div></li>
      <li><a class="btn btn-lg btn-success text-left" href="#">
     <img src="{{ asset('img/late-ico6.png') }}" alt="" ></a> <div class="text-center">Cursos</div></li>
      <li><a class="btn btn-lg btn-success text-left" href="#">
     <img src="{{ asset('img/late-ico7.png') }}" alt="" ></a><div class="text-center">Proyectos</div></li>
      <li><a class="btn btn-lg btn-success text-left" href="{{ url('/referidos') }}">
      <img src="{{ asset('img/late-ico8.png') }}" alt="" ></a><div class="text-center">Referidos</div></li>
      <li><a class="btn btn-lg btn-success text-left" href="#">
              <img src="{{ asset('img/late-ico9.png') }}" alt="" ></a><div class="text-center">Soporte</div></li>
      

      </ul>
  
  </nav>