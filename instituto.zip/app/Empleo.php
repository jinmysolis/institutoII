<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Empleo extends Model
{
    //
}
