<?php
header('Location: public');
?>